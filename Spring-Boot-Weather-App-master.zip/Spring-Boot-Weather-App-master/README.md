# Spring-Boot-Weather-App
A Spring Boot app that consumes weather and forecast data from openwethermap api and displays output in the form of json. 

Please paste your api key in the url of the service class
